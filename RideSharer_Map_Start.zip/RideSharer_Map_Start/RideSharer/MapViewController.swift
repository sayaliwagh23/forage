//
//  MapViewController.swift
//  RideSharer
//
//

import UIKit

class MapViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
